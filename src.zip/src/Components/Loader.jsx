import React from "react";

export default function Loader() {
  return (
    <div id="loader">
      <div className="loader">
        <span />
        <span />
      </div>
    </div>
  );
}
